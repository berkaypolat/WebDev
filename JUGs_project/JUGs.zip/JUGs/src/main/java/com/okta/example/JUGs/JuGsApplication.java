package com.okta.example.JUGs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuGsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuGsApplication.class, args);
	}

}
